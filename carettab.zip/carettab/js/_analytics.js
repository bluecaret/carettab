// Analytics
// var _gaq = _gaq || [];
// _gaq.push(['_setAccount', 'UA-64196229-2']);
// _gaq.push(['_trackPageview']);

// (function() {
//     var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
//     ga.src = 'https://ssl.google-analytics.com/ga.js';
//     var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
// })();

// // Track clicks
// function trackLinks(e) {
//     var target = e.target.id;
//     _gaq.push(['_trackEvent', target, 'Click', target]);
// };

// function trackTabs(e) {
//     var target = e.target.id;
//     _gaq.push(['_trackEvent', 'Setting Tabs', 'Click', target]);
// };

// document.addEventListener('DOMContentLoaded', function () {
//     var links = document.querySelectorAll('a');
//     for (var i = 0; i < links.length; i++) {
//         links[i].addEventListener('click', trackLinks);
//     }
//     var settingsTabs = document.querySelectorAll('#settings-tabs ul li');
//     for (var i = 0; i < settingsTabs.length; i++) {
//         settingsTabs[i].addEventListener('click', trackTabs);
//     }
// });
